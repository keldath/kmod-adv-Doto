#pragma once

#ifndef CIV4_PLOT_RANGE_H
#define CIV4_PLOT_RANGE_H

// advc.plotr: Wrapper header

#include "PlotRadiusIterator.h" // includes CvMap.h, CvPlot.h
#include "CityPlotIterator.h" // includes CvCity.h

#endif
